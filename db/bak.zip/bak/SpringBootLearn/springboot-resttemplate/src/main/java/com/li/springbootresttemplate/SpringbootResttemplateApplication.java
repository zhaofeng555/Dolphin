package com.li.springbootresttemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootResttemplateApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootResttemplateApplication.class, args);
    }

}

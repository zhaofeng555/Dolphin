DELETE FROM user;

INSERT INTO user (id, name, age, email, grade, gender) VALUES
(2, 'Jack', 3, 'test2@baomidou.com', 1, 0),
(3, 'Tom', 1, 'test3@baomidou.com', 2, 1),
(1, 'Billie', 2, 'test5@baomidou.com', 3, null);
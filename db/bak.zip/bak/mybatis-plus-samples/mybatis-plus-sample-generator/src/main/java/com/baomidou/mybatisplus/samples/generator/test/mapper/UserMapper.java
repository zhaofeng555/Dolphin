package com.baomidou.mybatisplus.samples.generator.test.mapper;

import com.baomidou.mybatisplus.samples.generator.test.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author haojg
 * @since 2019-06-22
 */
public interface UserMapper extends BaseMapper<User> {

}

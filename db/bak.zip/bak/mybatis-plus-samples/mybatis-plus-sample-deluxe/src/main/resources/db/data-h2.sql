DELETE
FROM user;

INSERT INTO user (id, name, age, email, version, deleted)
VALUES (1, 'Jone', 18, 'test1@baomidou.com',    1, 0),
       (2, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (3, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (4, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (5, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (6, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (7, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (8, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (9, 'Jack', 20, 'test2@baomidou.com',    1, 0),
       (10, 'Jack', 20, 'test2@baomidou.com',   1, 0),
       (11, 'Jack', 20, 'test2@baomidou.com',   1, 0),
       (12, 'Jack', 20, 'test2@baomidou.com',   1, 0),
       (13, 'Jack', 20, 'test2@baomidou.com',   1, 0),
       (14, 'Jack', 20, 'test2@baomidou.com',   1, 0),
       (15, 'Tom', 28, 'test3@baomidou.com',    1, 0),
       (16, 'Sandy', 21, 'test4@baomidou.com',  1, 0),
       (17, 'Billie', 24, 'test5@baomidou.com', 1, 0);
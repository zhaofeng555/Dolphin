package com.baomidou.mybatisplus.samples.generator.test.service.impl;

import com.baomidou.mybatisplus.samples.generator.test.entity.User;
import com.baomidou.mybatisplus.samples.generator.test.mapper.UserMapper;
import com.baomidou.mybatisplus.samples.generator.test.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author haojg
 * @since 2019-06-22
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

}

package com.baomidou.mybatisplus.samples.generator.test.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import com.baomidou.mybatisplus.samples.generator.common.BaseController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author haojg
 * @since 2019-06-22
 */
@Controller
@RequestMapping("/test/user")
public class UserController extends BaseController {

}

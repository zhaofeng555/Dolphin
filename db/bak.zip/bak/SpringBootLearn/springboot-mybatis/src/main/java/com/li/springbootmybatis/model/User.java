package com.li.springbootmybatis.model;

/**
 * @ClassName User
 * @Author lihaodong
 * @Date 2019/2/19 09:20
 * @Mail lihaodongmail@163.com
 * @Description
 * @Version 1.0
 **/

public class User {

    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

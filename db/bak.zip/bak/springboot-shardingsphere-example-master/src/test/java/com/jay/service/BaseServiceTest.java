package com.jay.service;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author jay.xiang
 * @create 2019/5/5 19:01
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class BaseServiceTest {

}

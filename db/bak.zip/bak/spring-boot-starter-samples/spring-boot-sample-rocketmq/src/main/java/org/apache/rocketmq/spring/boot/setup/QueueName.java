package org.apache.rocketmq.spring.boot.setup;

public class QueueName {

    public static final String LOG_QUEUE = "sample.queue";

}

package com.alibaba.druid.spring.boot.dao.daointerface;

public interface IUuidDao {

    String get();

}

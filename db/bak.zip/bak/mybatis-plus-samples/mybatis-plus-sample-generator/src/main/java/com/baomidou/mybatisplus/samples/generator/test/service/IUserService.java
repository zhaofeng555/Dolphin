package com.baomidou.mybatisplus.samples.generator.test.service;

import com.baomidou.mybatisplus.samples.generator.test.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author haojg
 * @since 2019-06-22
 */
public interface IUserService extends IService<User> {

}

package org.mybatis.spring.boot.service.svcinterface;

public interface IUuidService {

    public String get();

}

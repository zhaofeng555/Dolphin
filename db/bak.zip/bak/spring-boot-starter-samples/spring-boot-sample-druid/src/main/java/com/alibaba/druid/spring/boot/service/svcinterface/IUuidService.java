package com.alibaba.druid.spring.boot.service.svcinterface;

public interface IUuidService {

    public String get();

}

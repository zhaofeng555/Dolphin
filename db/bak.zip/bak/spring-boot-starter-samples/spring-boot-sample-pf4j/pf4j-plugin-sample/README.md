
#pf4j2-plugin-sample

基于pf4j2的插件简单示例


### pf4j2-plugin-api
1、插件接口定义

### pf4j2-plugin-impl1
1、插件实现1

### pf4j2-plugin-impl2
1、插件实现2

### pf4j2-plugin-test
1、插件测试
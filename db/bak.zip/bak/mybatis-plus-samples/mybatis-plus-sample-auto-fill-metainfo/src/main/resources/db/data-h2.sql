DELETE FROM user;

INSERT INTO user (id, name, age, email, operator)
VALUES (1, 'Jone', 18, 'test1@baomidou.com', 'test');

